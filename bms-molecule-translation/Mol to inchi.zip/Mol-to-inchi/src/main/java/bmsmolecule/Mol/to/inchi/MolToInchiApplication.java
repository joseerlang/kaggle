package bmsmolecule.Mol.to.inchi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MolToInchiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MolToInchiApplication.class, args);
	}

}
