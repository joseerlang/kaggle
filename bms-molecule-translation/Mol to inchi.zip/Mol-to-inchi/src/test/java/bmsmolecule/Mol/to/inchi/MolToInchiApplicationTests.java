package bmsmolecule.Mol.to.inchi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MolToInchiApplicationTests {

	@Test
	void contextLoads() {
	}

}
